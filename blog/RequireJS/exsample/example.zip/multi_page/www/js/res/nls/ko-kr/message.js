define({
    "root": {
        "red": "red",
        "blue": "blue",
        "green": "green"
    },
    "ko-kr": true
});
