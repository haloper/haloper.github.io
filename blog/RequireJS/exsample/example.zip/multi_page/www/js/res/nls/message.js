define({
    "root": {
        "red": "빨강",
        "blue": "파랑",
        "green": "초록"
    }
});
